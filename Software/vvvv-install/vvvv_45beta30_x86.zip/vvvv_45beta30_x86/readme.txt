-------------------------------------------------------------------
see http://vvvv.org for latest informations on vvvv
-------------------------------------------------------------------
Please note that by using this software, you agree to be bound
to the TERMS OF USAGE enclosed in license.txt
-------------------------------------------------------------------


install:
- extract the vvvv directory from the .zip archive to a
  nice place on your harddisk.

- start at least once crack.exe (needs admin rights!)

- if you face troubles, see:
    http://vvvv.org/documentation/troubleshooting

- run start_with_demo.bat to run vvvv with a demo patch

- start vvvv.exe to run a vanilla vvvv



more information
- you should find answers to all your questions at:
    http://vvvv.org/documentation

- if you're missing something tell us at the forums: 
    http://vvvv.org/forums



change log: 
- http://vvvv.org/documentation/change-log



system recommendations:
- 500MHz Pentium III or better
- Geforce-Class Graphics Card
- three-button mouse 
- windows XP, windows Vista, windows 7
- .net4
- latest release of directX 9c
        


uninstall:
- before deleting the directory containing vvvv run 
  crack.exe and click 'uninstall'



contact vvvv group: 
        group@vvvv.org
        http://vvvv.org

EOF.