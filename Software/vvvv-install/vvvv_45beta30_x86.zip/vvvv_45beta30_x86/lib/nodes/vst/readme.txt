in order to use VST plugins in vvvv 
you need to place them in this directory.

for all information about VST in vvvv refer to:
http://vvvv.org/documentation/vst  
