in order to use freeframe plugins in vvvv 
you need to place them in this directory.

for all information about freeframe in vvvv refer to:
http://vvvv.org/documentation/freeframes

a large number of plugins are available from:
http://freeframe.sourceforge.net/downloads.html
http://community.freeframe.org/

