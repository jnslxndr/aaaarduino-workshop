Version info:
CEF: 1.1364.1123
CefGlue: Changeset 131 (https://bitbucket.org/azeno/cefglue)

Get CEF from http://code.google.com/p/chromiumembedded/downloads/list
Get CefGlue from https://bitbucket.org/fddima/cefglue

Make sure versions match.